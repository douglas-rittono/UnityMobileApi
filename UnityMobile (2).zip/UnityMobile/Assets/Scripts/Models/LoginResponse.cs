using UnityEngine;

[System.Serializable]
public class LoginResponse
{
    [SerializeField]
    public string token;
}
