using TMPro;
using UnityEngine;

public class DetectTouchOnGameObject : MonoBehaviour
{
    public Transform configPosition;
    public Transform homePosition;
    public Transform phasesPosition;
    public float velocity = 2.0f;
    private Transform target;
    public TMP_Text txtShadow;
    private float lastTime;

    public Transform plataformPostionLeft;
    public Transform plataformPostionRight;
    public GameObject platform;
    bool GoingLeft;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        target = homePosition;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            if(Physics.Raycast(ray, out hit))
            {
                GameObject touchedObject = hit.collider.gameObject;

                if (touchedObject.CompareTag("Play"))
                {
                    target = phasesPosition;
                }
                else if (touchedObject.CompareTag("Config"))
                {
                    target = configPosition;
                }
                else if (touchedObject.CompareTag("Home"))
                {
                    target = homePosition;
                }
            }
        }


        if (target != null)
        {
            transform.position = Vector3.Lerp(transform.position, target.position, velocity * Time.deltaTime);
        }
    }

    private void FixedUpdate()
    {
        lastTime += Time.deltaTime;

        if(lastTime > 1) { 
            txtShadow.enabled = !txtShadow.enabled;
            lastTime = 0;
        }

        if(platform.transform.position.x <= -1.60)
        {
            GoingLeft = true;
        }
        if(platform.transform.position.x >= 1.60)
        {
            GoingLeft = false;
        }

        var targetposition = GoingLeft ? plataformPostionLeft : plataformPostionRight;
        platform.transform.position = Vector3.Lerp(platform.transform.position, targetposition.position, velocity * Time.deltaTime);
        
    }
}
