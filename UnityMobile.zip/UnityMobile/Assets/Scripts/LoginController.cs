using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LoginController : MonoBehaviour
{
    [Header("Input Field")]
    public TMP_InputField txtUsername;
    public TMP_InputField txtPassword;

    void Start()
    {
        
    }

    void Update()
    {
        
    }

    public void OpenCreateScene()
    {
        SceneManager.LoadScene("CreateUserScene");
    }

    public void Login()
    {
        var username = txtUsername.text;
        var password = txtPassword.text;

        Debug.Log(username);
        Debug.Log(password);

        PlayerPrefs.SetString("Username", username);

        SceneManager.LoadScene("PrincipalScene");
    }
}
